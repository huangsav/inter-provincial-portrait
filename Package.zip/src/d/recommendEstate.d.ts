declare namespace TSX {
    interface IntrinsicElements {
        FirstStepView: { changeFunc: string; test: string }
        SecondStepView: { estate: object; setValue: void }
    }
}