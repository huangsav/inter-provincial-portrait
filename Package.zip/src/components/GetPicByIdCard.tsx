import * as React from 'react';
import { Button, Input, Row, Col } from 'antd';

interface Pic {
    type: string
}
class GetPicByIdCard extends React.Component<Pic, any>{
    constructor(props:any){
        super(props);
    }
    render(){
        return (
            <div>
                <Row>
                    <Col span={3}>身份证</Col>
                    <Col span={6}><Input size="small" placeholder="身份证号"/></Col>
                    <Col span={3}><Button type="primary" icon="search" onClick={this.GetPictureByIdCard}>获取图片</Button></Col>
                </Row>
            </div>
        )
    }

    GetPictureByIdCard () {
        alert(this.props.type);
    }
}

export default GetPicByIdCard;