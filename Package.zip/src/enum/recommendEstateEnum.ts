// 刚升2.4新特性字符串枚举、编辑器报错但是其实是对的
export enum stepsTitle {
    one = '选择楼盘',
    two = '补全信息',
    three = '推荐成功'
}
