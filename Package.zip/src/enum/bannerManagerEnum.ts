// 刚升2.4新特性字符串枚举、编辑器报错但是其实是对的
export enum publishText {
    unpublish = '未发布',
    publish = '已发布',
}