export const userAction = (text: string) => {
    return {
        type: text
    };
}